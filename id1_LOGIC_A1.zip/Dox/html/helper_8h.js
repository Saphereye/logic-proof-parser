var helper_8h =
[
    [ "BLACK", "helper_8h.html#a7b3b25cba33b07c303f3060fe41887f6", null ],
    [ "BLUE", "helper_8h.html#a79d10e672abb49ad63eeaa8aaef57c38", null ],
    [ "GREEN", "helper_8h.html#acfbc006ea433ad708fdee3e82996e721", null ],
    [ "RED", "helper_8h.html#a8d23feea868a983c8c2b661e1e16972f", null ],
    [ "RESET", "helper_8h.html#ab702106cf3b3e96750b6845ded4e0299", null ],
    [ "YELLOW", "helper_8h.html#abf681265909adf3d3e8116c93c0ba179", null ],
    [ "clearScreen", "helper_8h.html#a9d7e8af417b6d543da691e9c0e2f6f9f", null ],
    [ "debug", "helper_8h.html#ad013e682fb854cb635040199b0c56dcc", null ],
    [ "error", "helper_8h.html#a3fcb7fed725c63c53fa1f15aa88f3854", null ],
    [ "error", "helper_8h.html#a5b72bc7d89749e9e93d79cbe153c940f", null ],
    [ "todo", "helper_8h.html#a8901b2fbbbdd8977801a3e60a8ebed3d", null ],
    [ "trace", "helper_8h.html#ae97399243e32acf4347dbd18fcf722fb", null ],
    [ "isDebugMode", "helper_8h.html#ae2e4f755cc94cf35e88fabd5da2572f5", null ]
];