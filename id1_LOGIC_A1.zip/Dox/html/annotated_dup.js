var annotated_dup =
[
    [ "Logic", "classLogic.html", "classLogic" ],
    [ "Operator", "classOperator.html", "classOperator" ],
    [ "Stack", "classStack.html", "classStack" ],
    [ "TruthValStore", "classTruthValStore.html", "classTruthValStore" ]
];