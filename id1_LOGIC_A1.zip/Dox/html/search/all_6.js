var searchData=
[
  ['logic_26',['Logic',['../classLogic.html',1,'']]],
  ['logic_2eh_27',['logic.h',['../logic_8h.html',1,'']]]
];
