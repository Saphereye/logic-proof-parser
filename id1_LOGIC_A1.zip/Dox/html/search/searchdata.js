var indexSectionsWithContent =
{
  0: "abcdgilmoprsty",
  1: "lost",
  2: "lmopst",
  3: "acdgimopst",
  4: "bgry",
  5: "mp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Macros",
  5: "Pages"
};

