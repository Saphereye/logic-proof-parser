var searchData=
[
  ['logic_52',['Logic',['../classLogic.html',1,'']]]
];
