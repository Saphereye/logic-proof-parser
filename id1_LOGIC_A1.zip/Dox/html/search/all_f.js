var searchData=
[
  ['yellow_53',['YELLOW',['../helper_8h.html#abf681265909adf3d3e8116c93c0ba179',1,'YELLOW():&#160;helper.h'],['../main_8cpp.html#abf681265909adf3d3e8116c93c0ba179',1,'YELLOW():&#160;main.cpp']]]
];
