var searchData=
[
  ['black_99',['BLACK',['../main_8cpp.html#a7b3b25cba33b07c303f3060fe41887f6',1,'main.cpp']]],
  ['blue_100',['BLUE',['../main_8cpp.html#a79d10e672abb49ad63eeaa8aaef57c38',1,'main.cpp']]]
];
