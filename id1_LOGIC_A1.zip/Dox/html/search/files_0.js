var searchData=
[
  ['logic_2eh_56',['logic.h',['../logic_8h.html',1,'']]]
];
