var searchData=
[
  ['green_101',['GREEN',['../main_8cpp.html#acfbc006ea433ad708fdee3e82996e721',1,'main.cpp']]]
];
