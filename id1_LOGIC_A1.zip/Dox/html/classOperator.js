var classOperator =
[
    [ "Operator", "classOperator.html#a9d1bb447e3215a4b927dd4c5fc932ae6", null ],
    [ "Operator", "classOperator.html#a229d95b80e8f12cc26fbd9c6685e77aa", null ],
    [ "Operator", "classOperator.html#ae85dc366ddd292823069c29225780698", null ],
    [ "addChildren", "classOperator.html#ac5a08c8ef4437a14d7be49b0aa908307", null ],
    [ "addLeftChild", "classOperator.html#a13629606c1c0f28c6f930292244ac7bf", null ],
    [ "addRightChild", "classOperator.html#a0972a4cd344d791b1468351576e9d80f", null ],
    [ "getLeftChild", "classOperator.html#af0bc63ef2feef7745e0e116c89ad93d6", null ],
    [ "getRightChild", "classOperator.html#a0183eab9f025e54da6529bd1cd887b73", null ],
    [ "getSymbol", "classOperator.html#a0bc70e32492c38d2cb8f53af82c7d872", null ],
    [ "isAtom", "classOperator.html#a094b0166b5f27f1324757648a94dbff5", null ],
    [ "isUnaryOperator", "classOperator.html#a19312e15f37b303f7f89308ca0f4e229", null ]
];