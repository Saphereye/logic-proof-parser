var files_dup =
[
    [ "logic.h", "logic_8h.html", "logic_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "operators.h", "operators_8h.html", [
      [ "Operator", "classOperator.html", "classOperator" ]
    ] ],
    [ "stack.h", "stack_8h.html", [
      [ "Stack", "classStack.html", "classStack" ]
    ] ],
    [ "truthValStore.h", "truthValStore_8h.html", [
      [ "TruthValStore", "classTruthValStore.html", "classTruthValStore" ]
    ] ]
];