var classTruthValStore =
[
    [ "TruthValStore", "classTruthValStore.html#ab5410d49eaf07eb5e1446aba1bf4a638", null ],
    [ "TruthValStore", "classTruthValStore.html#a8408b635d2018a0935d44ed6c289b165", null ],
    [ "TruthValStore", "classTruthValStore.html#abe0b0bde8c094bf9c72aea46f0e1260c", null ],
    [ "addAtom", "classTruthValStore.html#a2b41f9ee3fd4a99640af3f43f7a43791", null ],
    [ "getAtom", "classTruthValStore.html#a6072c5933a186643ba851ea89c4269d9", null ],
    [ "getAtomArray", "classTruthValStore.html#aa93136f781a901c1fb5e792a08ba121f", null ],
    [ "getAtomIndex", "classTruthValStore.html#a51b23ad51f33a83ff88ae44990476c1a", null ],
    [ "getTruthVal", "classTruthValStore.html#ae97fd169e9c18dd0878cc712aec16040", null ],
    [ "getTruthValArray", "classTruthValStore.html#a0d3ea32e495188a044c00eb9c148be81", null ],
    [ "setAtomArray", "classTruthValStore.html#a5265d28716fb30813d60e18e2b545acb", null ],
    [ "setTruthVal", "classTruthValStore.html#af19f38162365e1a365c4d4785663e789", null ],
    [ "setTruthVal", "classTruthValStore.html#ae1dab5a373d65380656eeab6a37686a5", null ]
];